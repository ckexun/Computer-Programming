// Exercise 4.18 Solution: ex04_18.cpp
// Display decimal, binary, octal and hexadecimal numbers.
#include <iostream>
using namespace std; 

int main()
{
   int number; // a positive integer less than 32
   int bit1;   // the rightmost bit of number
   int bit2;
   int bit3;
   int bit4;
   int bit5;   // the leftmost bit of number


}